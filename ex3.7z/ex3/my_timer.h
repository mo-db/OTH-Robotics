#ifndef MY_TIMER_H_INCLUDED
#define MY_TIMER_H_INCLUDED

#include "my_event.h"
#include <stdint.h>

#define TIMER_NULL 0x00
#define TIMER_ONE 0x01

struct Timer {
};

typedef uint8_t TimerType;

void set_timer(TimerType timer, int time, EventType event);
void start_timer(TimerType timer);
void cancel_timer(TimerType timer);

#endif // MY_TIMER_H_INCLUDED
