#ifndef MY_EVENT_H_INCLUDED
#define MY_EVENT_H_INCLUDED

#include <stdint.h>

typedef uint16_t EventType ;

static const EventType E1 = 1;
static const EventType E2 = E1 << 1;
static const EventType E3 = E2 << 1;
// ...

void set_event(EventType e);
uint8_t event_is_set(EventType e);
void clear_event(EventType e);

#endif // MY_EVENT_H_INCLUDED
