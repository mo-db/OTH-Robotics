#ifndef MY_EVENT_H_INCLUDED
#define MY_EVENT_H_INCLUDED

#include <stdint.h>

typedef uint16_t EventType ;

static const EventType LEFT_BUTTON_EVENT = 1;
static const EventType RIGHT_BUTTON_EVENT = 1 << 1;
static const EventType E3 = 1 << 2;
// ...

void set_event(EventType e);
uint8_t event_is_set(EventType e);
void clear_event(EventType e);

#endif // MY_EVENT_H_INCLUDED
