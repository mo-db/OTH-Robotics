#include "my_event.h"

uint16_t event_storage = 0;

void set_event(EventType event) {
    event_storage |= event;
}
uint8_t event_is_set(EventType event) {
    return ((event & event_storage) > 0 ? 1 : 0);
}
void clear_event(EventType event) {
    event_storage &= ~event;
}


