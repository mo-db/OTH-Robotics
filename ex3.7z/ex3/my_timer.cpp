#include "my_timer.h"

void set_timer(TimerType timer, int time, EventType event) {
}
void start_timer(TimerType timer) {
}
void cancel_timer(TimerType timer) {
}
