#include "my_timer.h"

Timer timers[TIMERS_COUNT];

void set_timer(TimerType id, int time, EventType event) {
    print_msg(0, "set timer");
    //taskENTER_CRITCAL();
    timers[id].duration = time;
    timers[id].event = event;
    //taskEXIT_CRITICAL();
}
void start_timer(TimerType id) {
    print_msg(0, "start timer");
    //taskENTER_CRITCAL();
    timers[id].active = 1;
    timers[id].start_time = GetSysTime();
    //taskEXIT_CRITICAL();
}
void cancel_timer(TimerType id) {
    timers[id].active = 0;
}

int out_of_time(TimerType id) {
    Timer timer = timers[id];
    return (GetSysTime() - timer.start_time) > timer.duration;
}

void update_timers() {
    while(1) {
        //taskENTER_CRITCAL();
        for (int timer_id = 0; timer_id < TIMERS_COUNT; timer_id++) {
            Timer timer = timers[timer_id];
            if (timer.active && out_of_time(timer_id)) {
                set_event(timer.event);
                cancel_timer(timer_id);
            }
        }
        //taskEXIT_CRITICAL();
        Delay(10);
    }
}
