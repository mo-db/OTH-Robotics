#ifndef MY_EVENT_H_INCLUDED
#define MY_EVENT_H_INCLUDED

#include "nnxt.h"
#include <stdint.h>
#include <stdio.h>
#include "print.h"

#define E1 0
#define E2 1
#define E3 2
#define E4 3
#define E5 4
#define E6 5
#define E7 6
#define E8 7
#define E9 8
#define E10 9
#define E11 10
#define E12 11
#define E13 12
#define E14 13
#define E15 14

typedef uint16_t EventType ;

void set_event(EventType e);
uint8_t event_is_set(EventType e);
void clear_event(EventType e);

#endif // MY_EVENT_H_INCLUDED
