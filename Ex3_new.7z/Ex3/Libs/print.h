#ifndef PRINT_H_INCLUDED
#define PRINT_H_INCLUDED

#include "nnxt.h"
#include <stdio.h>

void print_msg(int line, char* msg);

#endif // PRINT_H_INCLUDED
