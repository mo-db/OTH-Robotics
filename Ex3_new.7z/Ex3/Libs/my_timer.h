#ifndef MY_TIMER_H_INCLUDED
#define MY_TIMER_H_INCLUDED

#include "nnxt.h"
#include "my_event.h"
#include "print.h"
#include <stdint.h>
#include <stdio.h>

#define TIMERS_COUNT 5
#define T1 0
#define T2 1
#define T3 2
#define T4 3
#define T5 4

typedef struct Timer {
    uint32_t start_time;
    uint8_t active;
    int duration;
    EventType event;
} Timer;

typedef uint8_t TimerType;



void set_timer(TimerType id, int time, EventType event);
void start_timer(TimerType id);
void cancel_timer(TimerType id);

int out_of_time(TimerType id);
void update_timers();

#endif // MY_TIMER_H_INCLUDED
