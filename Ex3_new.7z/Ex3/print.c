#include "print.h"

void print_msg(int line, char* msg) {
    NNXT_LCD_DisplayStringAtLine(line, msg);
}
