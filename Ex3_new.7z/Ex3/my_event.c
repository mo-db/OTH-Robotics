#include "my_event.h"

volatile uint16_t event_storage = 0;

void set_event(EventType event) {
    //taskENTER_CRITCAL();
    event_storage |= 1 << event;
    //taskEXIT_CRITICAL();
}
uint8_t event_is_set(EventType event) {
    return (((1 << event) & event_storage) > 0 ? 1 : 0);
}
void clear_event(EventType event) {
    event_storage &= ~(1 << event);
}
