#include "nnxt.h"
#include <stdio.h>

#include "print.h"
#include "my_event.h"
#include "my_timer.h"

#define LEFT_BUTTON_EVENT E1
#define RIGHT_BUTTON_EVENT E2
#define MOTOR_STOP_EVENT E3

#define MOTOR_STOP_TIMER T1


void check_button_one() {
    sensor_touch_clicked_t button_state = SensorTouch_released;
    sensor_touch_clicked_t last_button_state = SensorTouch_released;

    while(1) {
        last_button_state = button_state;
        Touch_Clicked(Port_0, &button_state);
        if (last_button_state == SensorTouch_released && button_state == SensorTouch_clicked) {
            set_event(LEFT_BUTTON_EVENT);
        }
        Delay(100);
    }
}


void check_button_two() {
    sensor_touch_clicked_t button_state = SensorTouch_released;
    sensor_touch_clicked_t last_button_state = SensorTouch_released;

    while(1) {
        last_button_state = button_state;
        Touch_Clicked(Port_1, &button_state);
        if (last_button_state == SensorTouch_released && button_state == SensorTouch_clicked) {
            set_event(RIGHT_BUTTON_EVENT);
        }
        Delay(100);
    }
}

// set_timer(motor_drive_stop);
void check_events() {
    // state
    motor_dir_t motorDir = Motor_dir_forward;

    while(1) {
        // FSM
        if(event_is_set(LEFT_BUTTON_EVENT)) {
            clear_event(LEFT_BUTTON_EVENT);
            Motor_Drive(Port_A, motorDir, 35);
            Motor_Drive(Port_B, motorDir, 35);
            start_timer(MOTOR_STOP_TIMER);
        }
        else if (event_is_set(RIGHT_BUTTON_EVENT)) {
            clear_event(RIGHT_BUTTON_EVENT);
            motorDir = (motorDir == Motor_dir_forward) ? Motor_dir_backward : Motor_dir_forward;

        }
        else if (event_is_set(MOTOR_STOP_EVENT)) {
            clear_event(MOTOR_STOP_EVENT);
            Motor_Stop(Port_A, Motor_stop_float);
            Motor_Stop(Port_B, Motor_stop_float);
        }
        Delay(10);
    }
}


int main() {
    SensorConfig(Port_0, SensorTouch);
    SensorConfig(Port_1, SensorTouch);

    MotorPortInit(Port_A);
    MotorPortInit(Port_B);

    set_timer(MOTOR_STOP_TIMER, 1000, MOTOR_STOP_EVENT);

    CreateAndStartTask(check_button_one);
    CreateAndStartTask(check_button_two);

    CreateAndStartTask(check_events);
    CreateAndStartTask(update_timers);

    StartScheduler();

    return 0;
}
